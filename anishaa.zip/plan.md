# Anisha Singh — Digital Builder

## Implementation approach

Build a static-first, multi-route React 19 + TypeScript portfolio inside the initialized Vite/Tailwind project. Keep the existing static build and avoid enabling server, database, login, or external integrations. Use Wouter for routes, shared navigation/footer and reusable visual primitives; use structured TypeScript data for projects, services, skills, ventures, social/contact links, current-focus notes, and future journal entries. Implement case studies from shared data-driven templates. The contact/enquiry form provides client-side validation and clear success/error states but must disclose that it is a frontend demonstration and does not deliver submissions until an integration is configured.

The homepage hero follows the supplied 21st.dev Elias component prompt: editorial paper/ink palette; giant two-line display name; orange ink accent; tracing/flood/open splash; layered reveal; animated letter; interactive hardcover carousel; cursor/spotlight on fine pointers; responsive/mobile composition; reduced-motion support. Adapt its author/book language to Anisha and selected project dossiers without inventing authored books. Do not use the demo author's portrait or synthesize a likeness: no portrait is rendered until Anisha supplies one. Omit unknown social URLs, contact values, screenshots and business results; use explicit editable placeholders. Unverified project status is shown as “Status to confirm.”

## Structure and responsibilities

- `client/src/pages/`: Home, About, Work, case-study route, Anisha, Movement on Wheels, AI & Automation, Software, Skills, Contact and dormant Journal structure.
- `client/src/components/`: shared shell, navigation, footer, CTA, project cards/gallery/filter, form, status pill, and editorial layout primitives.
- `client/src/components/ui/`: adapted supplied Elias hero component.
- `client/src/data/`: editable project, venture, service, skill, focus and social/contact data.
- `client/src/index.css`: design tokens, editorial styles, responsive behavior and reduced-motion overrides.
- `public/manus-routes.json`: source-synchronized route manifest.

## Design system

Reference: supplied 21st.dev editorial author/ink composition, adapted as a personal digital-maker portfolio.

- Design movement: contemporary editorial print meets tactile ink illustration.
- Core principles: expressive typography; honest project storytelling; restrained, purposeful motion; distinct page personalities within one system.
- Color philosophy: warm paper `#f6f4f0`, near-black ink `#171412`, muted graphite, and vermilion/orange ink `#f15a3b`; use small pastel project-cover colors only as an accent.
- Layout paradigm: full-bleed hero and asymmetric editorial sections, alternating wide project frames and compact text columns; no generic dashboard/card grid.
- Signature elements: oversized outlined/filled name; orange ink rules and round CTA marks; tactile project “dossier” covers and paper-like section panels.
- Interaction: hover reveals and filters provide feedback; cursor treatment only on capable desktop pointers; all links/buttons have real targets/actions.
- Animation: one coordinated hero reveal, smooth low-amplitude page reveals and project transitions; no motion required for reading; honor `prefers-reduced-motion`.
- Typography: Inter Black (display), Figtree (body), IBM Plex Mono (micro-labels), with resilient system fallbacks.
- Brand essence: Anisha Singh’s evolving home for practical digital experiences, automation and creative ventures; curious, ambitious, hands-on.
- Voice: direct, thoughtful and builder-minded. Examples: “Turning ideas into things that work.” / “Curious by nature. Builder by choice.”
- Wordmark: compact custom-set “AS / ANISHA SINGH” monogram and wordmark, not a stock icon.
- Signature brand color: vermilion ink.

## Delivery boundaries

All requested routes and meaningful content are included, with Journal prepared but clearly inactive/empty. Use the user-provided contact phone `9309897997` and preserve the supplied email destination as an editable value unless a replacement is provided. No invented portrait, project visuals, completion status, tech credentials, testimonials, results, dates, awards, client claims or Movement on Wheels production credit. Missing visuals use editable, visibly illustrative browser/device frames, never implied actual screenshots. No deployment/publication was requested; preserve auto-publish off.
