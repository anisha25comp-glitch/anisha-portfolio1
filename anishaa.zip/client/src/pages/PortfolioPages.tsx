import { useMemo, useState } from "react";
import type { FormEvent } from "react";
import { Link } from "wouter";
import { CTA, PageFrame, PageIntro, ProjectVisual, SectionLabel } from "@/components/SiteShell";
import AnishaEnquiryForm from "@/components/AnishaEnquiryForm";
import AutomationEnquiryForm from "@/components/AutomationEnquiryForm";
import { contact, filters, futureJournalTopics, journey, movementBehindSceneSlots, movementPlatforms, projects, services, skills, socialProfiles } from "@/data/site";

const anishaProcess = [
  { title: "Discovery", description: "Understand the business, audience, goals and practical requirements." },
  { title: "Planning", description: "Agree on a clear structure, scope and useful next steps." },
  { title: "Design", description: "Shape the visual experience and customer journey around the brief." },
  { title: "Development", description: "Build the website or system with responsive behavior in mind." },
  { title: "Testing", description: "Check functionality, performance and responsiveness before launch." },
  { title: "Launch", description: "Deploy and hand over the agreed work." },
  { title: "Support", description: "Provide ongoing support when it is part of the agreement." },
];

const automationTools = ["n8n", "WhatsApp Business API", "APIs", "Webhooks", "AI models", "Google Sheets", "Google Calendar", "Automation tools"];

function ProjectCards({ items }: { items: typeof projects }) {
  return <div className="project-grid">{items.map((project, i) => <Link key={project.slug} href={`/work/${project.slug}`} className="project-card project-card-link">
    <ProjectVisual label={project.visual} index={`0${i + 1}`} />
    <div className="project-meta"><span>{project.category}</span><span className="status">{project.status}</span></div>
    <p className="project-role">Role · {project.role}</p>
    <h3>{project.title}</h3><p>{project.description}</p>
    <div className="tag-row">{project.tags.map(tag => <span className="tag" key={tag}>{tag}</span>)}</div>
  </Link>)}</div>;
}

function ProjectRibbon() {
  return <section className="wrap section"><SectionLabel index="01">PROJECT RIBBON / SELECT A STUDY</SectionLabel><div className="project-ribbon">{projects.map((project, i) => <Link key={project.slug} href={`/work/${project.slug}`} className={`project-ribbon-card ribbon-card-${i + 1}`}><span className="project-ribbon-index">0{i + 1} / {project.category.toUpperCase()}</span><span className="project-ribbon-orbit" aria-hidden="true">↗</span><strong>{project.title}</strong><span className="project-ribbon-status">{project.status}</span></Link>)}</div><p className="placeholder-note">A stylized index of selected work, not a gallery of client screenshots. Add supplied project imagery when available.</p></section>;
}

export function WorkPage() {
  const [active, setActive] = useState("All");
  const shown = useMemo(() => projects.filter(project => active === "All" || (active === "Experiments" ? project.kind === "experiment" : project.category === active || project.tags.includes(active))), [active]);
  return <PageFrame title="Selected Work" description="Websites, digital systems and automation explorations by Anisha Singh.">
    <PageIntro kicker="PORTFOLIO / 2026" title="Selected work." description="A collection of website projects, digital systems, automation explorations and creative collaborations. Project status and assets are shown only as confirmed." />
    <ProjectRibbon />
    <section className="wrap section"><SectionLabel index="02">PROJECT INDEX</SectionLabel><div className="filters" role="group" aria-label="Filter projects">{filters.map(filter => <button className={active === filter ? "filter-btn active" : "filter-btn"} key={filter} aria-pressed={active === filter} onClick={() => setActive(filter)}>{filter}</button>)}</div><ProjectCards items={shown} />{shown.length === 0 && <p className="placeholder-note">No projects in this category yet. More work can be added in the editable project data.</p>}</section>
    <CTA title="Want to make something useful?" text="Share the problem, the idea or the first sketch. We can figure out a practical next step." />
  </PageFrame>;
}

export function CaseStudyPage({ slug }: { slug: string }) {
  const project = projects.find(item => item.slug === slug);
  if (!project) return <PageFrame title="Project not found" description="This project could not be found."><section className="wrap section"><h1>Project not found.</h1><Link className="inline-link" href="/work">Back to work ↗</Link></section></PageFrame>;
  const index = projects.indexOf(project);
  const next = projects[(index + 1) % projects.length];
  return <PageFrame title={project.title} description={project.description}>
    <section className="case-hero wrap"><p className="eyebrow">CASE FILE / {project.category.toUpperCase()}</p><h1>{project.title}</h1><p className="page-lede">{project.description}</p><div className="project-meta"><span>{project.role}</span><span className="status">{project.status}</span></div><ProjectVisual label={project.visual} index={`0${index + 1}`} /><p className="placeholder-note">Illustrative project placeholder — not a supplied client screenshot.</p></section>
    <section className="wrap section case-details"><div><p className="eyebrow">AT A GLANCE</p><p><strong>Category</strong><br />{project.category}</p><p><strong>My role</strong><br />{project.role}</p><p><strong>Status</strong><br />{project.status}</p><p className="placeholder-note">{project.statusNote}</p></div><div><SectionLabel index="01">OVERVIEW</SectionLabel><h2 className="section-title">The brief</h2><p className="section-copy">{project.context}</p><SectionLabel index="02">OBJECTIVE</SectionLabel><p className="section-copy">{project.objective}</p><SectionLabel index="03">DIRECTION</SectionLabel><p className="section-copy">{project.solution}</p></div></section>
    <section className="wrap section"><SectionLabel index="04">SCOPE & FEATURES</SectionLabel><div className="line-list">{project.features.map((feature, i) => <div className="line-item" key={feature}><strong>{feature}</strong><span>0{i + 1}</span></div>)}</div></section>
    <section className="wrap section"><SectionLabel index="05">PROCESS & TECHNOLOGY</SectionLabel><div className="case-future-details"><article><h3>Design & development process</h3><p className="placeholder-note">Project-specific process details have not been supplied yet.</p></article><article><h3>Tools and technology</h3><p className="placeholder-note">The technology stack has not been confirmed; no tools are claimed here.</p></article></div></section>
    <section className="wrap section"><SectionLabel index="06">VISUALS, CHALLENGES & OUTCOMES</SectionLabel><div className="case-future-details"><article><h3>Project visuals</h3><p className="placeholder-note">Add supplied screenshots, desktop/mobile previews or video here. The illustration above is not actual client work.</p></article><article><h3>Challenges & verified results</h3><p className="placeholder-note">No project-specific challenges or verified results have been supplied.</p></article></div><p className="placeholder-note">Live project URL: not provided.</p></section>
    <section className="wrap section"><SectionLabel index="07">RELATED PROJECT</SectionLabel><ProjectCards items={[next]} /><Link className="inline-link" href={`/work/${next.slug}`}>Next case study: {next.title} ↗</Link><br /><Link className="inline-link" href="/work">All selected work ↗</Link></section>
    <CTA title="Have a project in mind?" text="Let's talk about what you are building." />
  </PageFrame>;
}

export function AboutPage() {
  return <PageFrame title="About" description="Anisha Singh is a Computer Science student, developer and entrepreneur exploring technology, creativity and practical problem-solving.">
    <PageIntro kicker="ABOUT / ANISHA SINGH" title="Curious by nature. Builder by choice." description="I'm a Computer Science student, developer and entrepreneur passionate about building things that combine technology, creativity and real-world problem solving." />
    <section className="wrap section intro-split"><div><SectionLabel index="01">THE SHORT VERSION</SectionLabel></div><div><p className="section-copy">I enjoy taking ideas from their earliest stages, figuring out how they can work, and turning them into something people can actually use. My work moves across web development, automation, digital business and creative collaborations.</p></div></section>
    <section className="wrap section"><SectionLabel index="02">A JOURNEY IN PROGRESS</SectionLabel><h2 className="section-title">Learning by making.</h2><div className="timeline">{journey.map((item, i) => <article className="timeline-item" key={item.title}><span>0{i + 1}</span><div><strong>{item.title}</strong><p>{item.text}</p></div></article>)}</div><p className="placeholder-note">An editable story structure — dates and milestones can be added when confirmed.</p></section>
    <section className="wrap section"><SectionLabel index="03">WHAT I KEEP COMING BACK TO</SectionLabel><div className="tag-row">{["Technology", "Entrepreneurship", "Web development", "AI", "Software", "Design", "Business", "Creativity", "Problem-solving", "Learning", "Building independently"].map(item => <span className="tag" key={item}>{item}</span>)}</div></section>
    <section className="wrap section"><SectionLabel index="04">A FEW THINGS I BELIEVE</SectionLabel><p className="editorial-quote">“I don't just want to learn how things work. I want to build things that work.”</p><p className="editorial-quote">“Ideas are exciting. Execution is what makes them real.”</p></section>
    <section className="wrap section"><SectionLabel index="05">BUILDING TOWARD</SectionLabel><div className="line-list">{["Build digital businesses", "Develop useful software", "Create scalable products", "Build AI-powered solutions", "Work with ambitious businesses", "Combine technology and creativity", "Keep learning and improving"].map((item, i) => <div className="line-item" key={item}><strong>{item}</strong><span>0{i + 1}</span></div>)}</div></section>
    <CTA title="Let's connect, collaborate or build something." text="A good conversation can be the beginning of a useful thing." />
  </PageFrame>;
}

export function AnishaPage() {
  const [activeProcess, setActiveProcess] = useState(0);
  const currentStep = anishaProcess[activeProcess];
  return <PageFrame title="Anisha Digital" description="Anisha Digital is Anisha Singh's digital solutions business, focused on business websites, digital experiences and practical technology.">
    <PageIntro kicker="A BUSINESS BY ANISHA SINGH" title="Build. Elevate. Grow." description="Digital solutions designed to help businesses build their presence, attract customers and simplify their operations." />
    <div className="anisha-hero-actions wrap"><a className="inline-link" href="#anisha-enquiry">Start a project ↘</a><a className="inline-link" href="#services">Explore services ↓</a></div>
    <section className="wrap section"><div className="venture-stamp large">ANISHA<br /><span>DIGITAL</span><i>BUILD · ELEVATE · GROW</i></div><SectionLabel index="01">ABOUT ANISHA</SectionLabel><p className="section-copy">Anisha Digital works on websites, digital experiences, automation and business-focused solutions. The goal is to help businesses establish a better digital presence and use technology to improve customer experience and workflows.</p></section>
    <section className="wrap section" id="services"><SectionLabel index="02">SERVICES</SectionLabel><div className="card-grid">{services.map((service, i) => <article className="info-card" key={service.title}><p className="eyebrow">0{i + 1}</p><h3>{service.title}</h3><p>{service.text}</p></article>)}</div></section>
    <section className="wrap section"><SectionLabel index="03">HOW A PROJECT MOVES</SectionLabel><div className="anisha-process"><div className="anisha-process-steps" role="group" aria-label="Choose a project stage">{anishaProcess.map((step, i) => <button className="anisha-process-step" key={step.title} type="button" aria-pressed={activeProcess === i} onClick={() => setActiveProcess(i)}><span>0{i + 1}</span><strong>{step.title}</strong><span aria-hidden>{activeProcess === i ? "−" : "+"}</span></button>)}</div><div className="anisha-process-detail" aria-live="polite"><p className="eyebrow">STAGE / 0{activeProcess + 1}</p><h3>{currentStep.title}</h3><p>{currentStep.description}</p></div></div></section>
    <section className="wrap section"><SectionLabel index="04">A PRACTICAL APPROACH</SectionLabel><div className="tag-row">{["Custom solutions", "Business-focused", "Responsive websites", "Modern technology", "Clear communication", "Tailored workflows", "Practical solutions", "Ongoing improvement"].map(item => <span className="tag" key={item}>{item}</span>)}</div></section>
    <section className="wrap section"><SectionLabel index="05">SELECTED BUSINESS PROJECTS</SectionLabel><ProjectCards items={projects.filter(project => project.kind === "client-work")} /></section>
    <section className="wrap section" id="anisha-enquiry"><SectionLabel index="06">PROJECT ENQUIRY</SectionLabel><h2 className="section-title">Tell us what you want to build.</h2><p className="section-copy">Share a little about your business, the service you need and the outcome you're working toward.</p><AnishaEnquiryForm /></section>
    <CTA title="Let's build your business's digital presence." text="Describe your project and the outcome you're working toward." label="CONTACT ANISHA" />
  </PageFrame>;
}

export function MovementPage() {
  return <PageFrame title="Movement on Wheels" description="A cinematic video-shooting and media collaboration. Anisha's involvement is focused on website and digital work.">
    <PageIntro kicker="CREATIVE COLLABORATION / MEDIA" title="Movement on Wheels" description="Stories in motion." />
    <section className="wrap section"><div className="movement-feature"><div className="movement-mark large">M<br /><span>O</span><i>STORIES IN MOTION</i></div><p className="section-copy">Movement on Wheels is a media/video-shooting channel and creative collaboration focused on capturing visual content and experiences. The exact niche and official information can be added when confirmed.</p></div></section>
    <section className="wrap section"><SectionLabel index="01">FEATURED VIDEOS</SectionLabel><div className="card-grid">{["Video feature 01", "Video feature 02", "Video feature 03"].map((item, i) => <div className="info-card" key={item}><div className="video-placeholder" role="img" aria-label={`Placeholder for ${item}`}><span>▶</span></div><p className="eyebrow">VIDEO SLOT / 0{i + 1}</p><h3>{item}</h3><p>Video thumbnail, title, description, category and channel links can be added here.</p><span className="placeholder-note">Awaiting supplied media</span></div>)}</div></section>
    <section className="wrap section"><SectionLabel index="02">BEHIND THE SCENES</SectionLabel><div className="card-grid">{movementBehindSceneSlots.map((item, i) => <div className="info-card" key={item}><div className="video-placeholder" role="img" aria-label={`Placeholder for ${item}`}><span>＋</span></div><p className="eyebrow">MEDIA SLOT / 0{i + 1}</p><h3>{item}</h3><p>Placeholder for supplied collaboration imagery or footage.</p></div>)}</div></section>
    <section className="wrap section"><SectionLabel index="03">CHANNEL LINKS</SectionLabel><div className="tag-row">{movementPlatforms.map(platform => <span className="tag" key={platform}>{platform} / LINK TO ADD</span>)}</div><p className="placeholder-note">No channel URLs or media assets have been supplied yet.</p></section>
    <section className="wrap section"><SectionLabel index="04">MY INVOLVEMENT</SectionLabel><h2 className="section-title">Digital work behind<br />the scenes.</h2><p className="section-copy">My involvement is connected to website development, digital presence, technology and related digital work. I do not claim filming, directing, editing or production credit.</p></section>
    <CTA title="Interested in a creative or digital collaboration?" text="Let's talk about how technology and creative work can come together." />
  </PageFrame>;
}

export function AutomationPage() {
  const groups = ["AI business assistants", "WhatsApp automation", "Workflow automation", "Lead management", "Appointment automation", "Business integrations"];
  const descriptions = ["Business-specific assistants that answer from approved information.", "Enquiry handling, FAQ responses, lead collection and routing.", "Connecting applications, data, webhooks and notifications.", "Capturing and tracking enquiries with follow-up workflows.", "Booking, confirmation, reminder and rescheduling flows.", "Exploring Calendar, Sheets, messaging, APIs and CRM tools."];
  return <PageFrame title="AI & Automation" description="Anisha Singh explores AI-powered business assistants, messaging automation and connected workflows.">
    <PageIntro kicker="PRACTICE / AI SYSTEMS" title="Making business workflows smarter." description="Exploring intelligent systems that can help businesses respond to customers, manage enquiries and connect their tools." />
    <section className="wrap section"><SectionLabel index="01">WHAT I EXPLORE</SectionLabel><div className="card-grid">{groups.map((group, i) => <article className="info-card" key={group}><p className="eyebrow">0{i + 1} / SYSTEM</p><h3>{group}</h3><p>{descriptions[i]}</p></article>)}</div></section>
    <section className="wrap section"><SectionLabel index="02">A WORKFLOW, AT A GLANCE</SectionLabel><div className="workflow">{["Customer message", "Understand enquiry", "Approved info", "Route or capture", "Response"].map((step, i) => <span key={step}>{step}{i < 4 && <i aria-hidden> → </i>}</span>)}</div><p className="placeholder-note">Illustrative workflow only. Integrations and feature implementation vary by project.</p></section>
    <section className="wrap section"><SectionLabel index="03">TOOLS / EXPERIENCE TO CONFIRM</SectionLabel><div className="tag-row">{automationTools.map(tool => <span className="tag" key={tool}>{tool} · USE / LEARNING STATUS TO CONFIRM</span>)}</div><p className="placeholder-note">Tool familiarity has not been confirmed; this editable list avoids implying a specific level of experience.</p></section>
    <section className="wrap section"><SectionLabel index="04">FEATURED EXPLORATION</SectionLabel><ProjectCards items={projects.filter(project => project.category === "AI & Automation")} /><p className="placeholder-note">Implementation state, demo, screenshots and limitations require confirmation; planned features are not represented as live.</p></section>
    <section className="wrap section"><SectionLabel index="05">AUTOMATION ENQUIRY</SectionLabel><h2 className="section-title">What would you like to automate?</h2><p className="section-copy">Share your business context, the workflow today and the problem you want to solve.</p><AutomationEnquiryForm /></section>
    <CTA title="Let's automate the repetitive work." text="Tell me what your current process looks like and where the friction is." />
  </PageFrame>;
}

export function SoftwarePage() {
  return <PageFrame title="Software & Digital Products" description="Exploring applications, systems, tools and digital products that solve real problems.">
    <PageIntro kicker="PRODUCTS / EXPERIMENTS" title="Beyond websites." description="Exploring and building applications, systems, tools and digital products that solve real problems." />
    <section className="wrap section"><SectionLabel index="01">PRODUCT LANDSCAPE</SectionLabel><div className="tag-row">{["CRM systems", "Clinic management", "Appointment management", "Business dashboards", "Inventory management", "SaaS concepts", "AI-powered applications", "Custom tools"].map(item => <span className="tag" key={item}>{item}</span>)}</div></section>
    <section className="wrap section"><SectionLabel index="02">ON THE PRODUCT RADAR</SectionLabel><div className="product-concept"><p className="eyebrow">CONCEPT / NOT A COMPLETED PRODUCT</p><h2 className="section-title">Anisha Business Manager</h2><p className="section-copy">A potential business management application. The idea explores customer management, leads, appointments, follow-ups, dashboards, analytics, notifications, an AI assistant and business records.</p><div className="tag-row">{["Customers", "Leads", "Appointments", "Follow-ups", "Dashboard", "Analytics", "Notifications", "AI assistant"].map(item => <span className="tag" key={item}>{item}</span>)}</div><span className="status">Concept</span></div></section>
    <section className="wrap section"><SectionLabel index="03">EXPERIMENTS</SectionLabel><div className="line-list">{["Small applications", "Interactive tools", "AI experiments", "Coding projects", "UI experiments", "Mini products", "Prototypes"].map((item, i) => <div className="line-item" key={item}><strong>{item}</strong><span>0{i + 1} / FUTURE SLOT</span></div>)}</div></section>
    <CTA title="Useful products start with real problems." text="I'm interested in tools that improve workflows and grow beyond a single project." />
  </PageFrame>;
}

export function SkillsPage() {
  return <PageFrame title="Skills & Expertise" description="Areas of practice and technologies Anisha Singh uses or is learning, without unsupported skill scores.">
    <PageIntro kicker="PRACTICE / TOOLKIT" title="A toolkit in motion." description="A growing set of skills across web development, automation, digital design, business and creative collaboration." />
    <section className="wrap section"><div className="card-grid">{skills.map((group, i) => <article className="info-card" key={group.title}><p className="eyebrow">0{i + 1} / PRACTICE</p><h3>{group.title}</h3><div className="tag-row">{group.items.map(item => <span className="tag" key={item}>{item}</span>)}</div></article>)}</div></section>
    <section className="wrap section"><SectionLabel index="02">TECHNOLOGIES & TOOLS / STATUS TO CONFIRM</SectionLabel><div className="tag-row">{automationTools.map(tool => <span className="tag" key={tool}>{tool} · USE / LEARNING STATUS TO CONFIRM</span>)}</div><p className="placeholder-note">No tool proficiency is claimed here until experience versus active learning is confirmed.</p></section>
    <CTA title="Have a challenge to solve?" text="Let's find out whether my current toolkit is a good fit." />
  </PageFrame>;
}

export function ContactPage() {
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) {
      setError("Please check the required fields and correct any invalid details.");
      return;
    }
    setError("");
    setSent(true);
    form.reset();
  }
  return <PageFrame title="Contact" description="Contact Anisha Singh about website projects, AI automation, software ideas and creative collaborations.">
    <PageIntro kicker="CONTACT / COLLABORATION" title="Let's turn your idea into something real." description="I'm open to website projects, AI automation, software ideas, digital projects, creative collaborations and interesting opportunities." />
    <section className="wrap section contact-layout"><div><SectionLabel index="01">ANISHA SINGH / DIRECT CONTACT</SectionLabel><div className="line-list"><a className="line-item" href={`mailto:${contact.email}`} aria-label="Email Anisha"><strong>Email Anisha</strong><span>EMAIL ↗</span></a><a className="line-item" href={contact.phoneHref}><strong>{contact.phone}</strong><span>PHONE ↗</span></a></div><div className="footer-socials">{socialProfiles.map(profile => profile.href ? <a key={profile.label} href={profile.href} target="_blank" rel="noreferrer">{profile.label}</a> : <span key={profile.label} className="social-placeholder">{profile.label} / ADD LINK</span>)}</div></div>
      <div><SectionLabel index="02">PROJECT ENQUIRY</SectionLabel><form className="form-grid" onSubmit={submit} onInvalidCapture={() => setError("Please check the required fields and correct any invalid details.")} onChange={() => { setError(""); if (sent) setSent(false); }}>
        <div className="field"><label htmlFor="name">Full name *</label><input id="name" name="name" required autoComplete="name" /></div>
        <div className="field"><label htmlFor="email">Email *</label><input id="email" name="email" type="email" required autoComplete="email" /></div>
        <div className="field full"><label htmlFor="whatsapp">WhatsApp number (optional)</label><input id="whatsapp" name="whatsapp" type="tel" autoComplete="tel" /></div>
        <div className="field full"><label htmlFor="type">Project type *</label><select id="type" name="type" required defaultValue=""><option value="" disabled>Choose one</option>{["Website development", "AI automation", "Software", "Digital presence", "Creative collaboration", "Not sure yet"].map(item => <option key={item}>{item}</option>)}</select></div>
        <div className="field full"><label htmlFor="description">What would you like to build? *</label><textarea id="description" name="description" required minLength={10} placeholder="A few sentences are enough." /></div>
        <div className="field full"><button className="form-button" type="submit">SUBMIT ENQUIRY ↗</button></div>
      </form>{error && <p className="form-error" role="alert">{error} Browser validation will identify the specific field to correct.</p>}{sent && <p className="success-note" role="status">The form was validated in this browser only. Nothing has been sent or stored; connect an enquiry service before using this for live messages.</p>}<p className="form-note">Frontend form only — enquiries are not sent or stored until an integration is configured. For now, use the direct email or phone links.</p></div>
    </section>
    <section className="wrap section"><SectionLabel index="03">OPEN TO</SectionLabel><div className="tag-row">{["Business partnerships", "Creative projects", "Startup ideas", "Freelance projects", "Internship opportunities", "Technical collaborations", "Other opportunities"].map(item => <span className="tag" key={item}>{item}</span>)}</div></section>
  </PageFrame>;
}

export function JournalPage() {
  return <PageFrame title="Journal" description="An editorial space prepared for future notes and articles by Anisha Singh.">
    <PageIntro kicker="NOTES / FUTURE SPACE" title="A journal, when it's ready." description="A place for project breakdowns, learning notes and ideas in progress. No articles or publication dates have been added yet." />
    <section className="wrap section"><SectionLabel index="01">POSSIBLE SUBJECTS</SectionLabel><div className="tag-row">{futureJournalTopics.map(item => <span className="tag" key={item}>{item}</span>)}</div><p className="placeholder-note">This structure is ready for future articles; it contains no invented posts.</p></section>
  </PageFrame>;
}
