import { Route, Switch, useRoute } from "wouter";
import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import NotFound from "./pages/NotFound";
import Home from "./pages/Home";
import { AboutPage, AnishaPage, AutomationPage, ContactPage, JournalPage, MovementPage, SkillsPage, SoftwarePage, WorkPage, CaseStudyPage } from "./pages/PortfolioPages";

function CaseRoute() {
  const [match, params] = useRoute<{ slug: string }>("/work/:slug");
  return match ? <CaseStudyPage slug={params.slug}/> : <NotFound/>;
}

function Router() {
  return <Switch>
    <Route path="/" component={Home}/>
    <Route path="/about" component={AboutPage}/>
    <Route path="/work" component={WorkPage}/>
    <Route path="/work/:slug" component={CaseRoute}/>
    <Route path="/anisha" component={AnishaPage}/>
    <Route path="/movement-on-wheels" component={MovementPage}/>
    <Route path="/ai-automation" component={AutomationPage}/>
    <Route path="/software" component={SoftwarePage}/>
    <Route path="/skills" component={SkillsPage}/>
    <Route path="/contact" component={ContactPage}/>
    <Route path="/journal" component={JournalPage}/>
    <Route path="/404" component={NotFound}/>
    <Route component={NotFound}/>
  </Switch>;
}

export default function App() {
  return <ErrorBoundary><ThemeProvider defaultTheme="light"><TooltipProvider><Toaster/><Router/></TooltipProvider></ThemeProvider></ErrorBoundary>;
}
