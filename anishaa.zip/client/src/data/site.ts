export type Project = {
  slug: string;
  title: string;
  category: string;
  description: string;
  role: string;
  status: string;
  tags: string[];
  visual: string;
  context: string;
  objective: string;
  solution: string;
  features: string[];
  statusNote: string;
  kind: "client-work" | "business" | "experiment" | "collaboration";
};

export const contact = {
  phone: "9309897997",
  email: "apexwebsites.india@gmail.com",
  phoneHref: "tel:9309897997",
};

export const projects: Project[] = [
  {
    slug: "a-one-salon",
    title: "A-One Salon",
    category: "Websites",
    description: "A business website project focused on salon services, brand identity, customer experience and digital presence.",
    role: "Website design and development",
    status: "Status to confirm",
    tags: ["Website", "Responsive design", "Service presentation"],
    visual: "SALON / DIGITAL PRESENCE",
    context: "A salon needs a clear and welcoming way to introduce its services and online presence.",
    objective: "Present services and brand identity through a clear, responsive business website.",
    solution: "A business website concept focused on service discovery, brand presentation and customer pathways. The final implementation status and supplied assets are to be confirmed.",
    features: ["Service presentation", "Responsive layout", "Customer contact pathway"],
    statusNote: "Project status and live URL have not yet been supplied.",
    kind: "client-work",
  },
  {
    slug: "lavi-aesthetics",
    title: "Lavi Aesthetics",
    category: "Websites",
    description: "An aesthetics clinic website project focused on professional digital presence and clear customer contact pathways.",
    role: "Website design/development; contribution details to confirm",
    status: "Status to confirm",
    tags: ["Clinic website", "Responsive experience", "SEO foundations"],
    visual: "LAVI / AESTHETICS",
    context: "An aesthetics clinic benefits from a professional place to present services and help prospective customers get in touch.",
    objective: "Present clinic services and provide clear contact pathways across devices.",
    solution: "A clinic-focused website project covering service presentation, contact integration, responsive experience and SEO foundations. No ranking results are claimed.",
    features: ["Service presentation", "Contact integration", "Responsive experience", "SEO foundations"],
    statusNote: "Project status, live URL and screenshots have not yet been supplied.",
    kind: "client-work",
  },
  {
    slug: "coffee-gruham",
    title: "Coffee Gruham",
    category: "Websites",
    description: "A café digital experience project focused on presenting the brand, menu, products and customer experience online.",
    role: "Website concept / design / development; exact contribution to confirm",
    status: "Status to confirm",
    tags: ["Café", "Digital experience", "Menu"],
    visual: "COFFEE / GRUHAM",
    context: "A café can use a digital experience to introduce its brand, menu and products to customers.",
    objective: "Create a useful online presentation for the café and its customer experience.",
    solution: "A café website project with potential brand, menu, product and contact presentation. Its live or concept status remains to be confirmed.",
    features: ["Brand presentation", "Digital menu", "Product presentation", "Contact pathway"],
    statusNote: "Status and actual project assets have not yet been supplied.",
    kind: "client-work",
  },
  {
    slug: "ai-whatsapp-receptionist",
    title: "AI WhatsApp Receptionist",
    category: "AI & Automation",
    description: "An AI-powered business assistant concept for handling enquiries, sharing approved business information, capturing leads and supporting appointment workflows.",
    role: "System design and automation exploration",
    status: "Status to confirm",
    tags: ["AI", "WhatsApp", "Workflow automation"],
    visual: "MESSAGE → UNDERSTAND → ROUTE",
    context: "Businesses receive recurring customer enquiries that can involve information lookup, lead capture and appointment coordination.",
    objective: "Explore an assistant that can answer using approved business information and support enquiry workflows.",
    solution: "A system concept involving a WhatsApp integration, AI responses, business knowledge, lead capture and appointment workflow elements. Implementation state for each feature must be confirmed before claiming availability.",
    features: ["WhatsApp integration (planned/being explored)", "AI responses (planned/being explored)", "Business knowledge (planned/being explored)", "Lead capture (planned/being explored)", "Calendar and Sheets integrations (planned/being explored)"],
    statusNote: "The brief lists these features as explored/implemented; exact implemented scope is not confirmed.",
    kind: "experiment",
  },
];

export const filters = ["All", "Websites", "AI & Automation", "Software", "Digital", "Creative", "Experiments"];

export const services = [
  { title: "Website Development", text: "Business websites, landing pages and responsive digital experiences shaped around a clear purpose." },
  { title: "UI / UX", text: "Thoughtful structure, visual design and mobile-first customer journeys." },
  { title: "Digital Presence", text: "Business presentation and practical on-page or local SEO foundations, without ranking guarantees." },
  { title: "AI & Automation", text: "Exploring useful assistants, WhatsApp flows, enquiry handling and connected workflows." },
  { title: "Business Systems", text: "Practical tools and integrations for customer management, appointments and everyday operations." },
];

export const focus = ["Building Anisha Digital", "Developing websites for businesses", "Exploring AI business automation", "Building WhatsApp automation workflows", "Learning software development", "Developing digital systems and products", "Working on creative collaborations"];

export const skills = [
  { title: "Web development", items: ["HTML", "CSS", "JavaScript", "Responsive design", "Website development", "Frontend development", "UI implementation"] },
  { title: "AI & automation", items: ["AI agents", "Workflow automation", "n8n", "APIs", "Webhooks", "WhatsApp integrations", "Business automation"] },
  { title: "Digital & design", items: ["UI/UX", "Website design", "Digital presentation", "SEO foundations", "Local SEO", "Digital presence"] },
  { title: "Business", items: ["Entrepreneurship", "Client communication", "Project planning", "Business problem-solving", "Digital strategy", "Sales", "Project management"] },
  { title: "Creative", items: ["Creative thinking", "Visual presentation", "Media collaborations", "Digital content projects"] },
];

export const journey = [
  { title: "The Beginning", text: "An early interest in technology, creativity and making things." },
  { title: "Learning", text: "A Computer Science journey alongside programming, web development and digital tools." },
  { title: "Building", text: "Developing websites, experimenting with design and creating digital projects." },
  { title: "Exploring AI", text: "Exploring AI agents, automation, integrations and intelligent business workflows." },
  { title: "Entrepreneurship", text: "Building Anisha Digital, working on business projects and exploring ways to turn technical skills into services." },
  { title: "Creative Collaborations", text: "Working on projects such as Movement on Wheels and exploring how technology can support creative work." },
  { title: "What's Next", text: "Developing software, digital products and AI systems while growing businesses and continuing to learn." },
];

export const futureJournalTopics = ["My website development journey", "Building Anisha Digital", "AI automation projects", "Learning software development", "Project breakdowns", "Business lessons", "Technology experiments", "Creative collaborations"];

export const projectStatusPlaceholder = "Status to confirm";


export const homeCategories = [
  { title: "Web Development", text: "Websites, landing pages, responsive design and digital experiences for businesses.", href: "/work" },
  { title: "AI & Automation", text: "AI assistants, WhatsApp workflows, integrations and practical business automation.", href: "/ai-automation" },
  { title: "Software & Digital Products", text: "Applications, business systems, SaaS ideas, tools and experiments.", href: "/software" },
  { title: "Creative Collaborations", text: "Media collaborations and creative technology, with my digital role described clearly.", href: "/movement-on-wheels" },
];

export const socialProfiles: Array<{ label: string; href: string | null }> = [
  { label: "Instagram", href: null },
  { label: "LinkedIn", href: null },
  { label: "GitHub", href: null },
];

export const movementPlatforms = ["YouTube", "Instagram", "Website"];
export const movementBehindSceneSlots = ["Shoot setup", "Equipment / location", "Behind the scenes"];
