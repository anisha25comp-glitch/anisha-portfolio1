import { useState } from "react";
import type { FormEvent } from "react";

export default function AutomationEnquiryForm() {
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) {
      setError("Please check the required fields and correct any invalid details.");
      return;
    }
    setError("");
    setSent(true);
    form.reset();
  }

  return (
    <>
      <form className="form-grid automation-enquiry-form" onSubmit={submit} onInvalidCapture={() => setError("Please check the required fields and correct any invalid details.")} onChange={() => { setError(""); if (sent) setSent(false); }}>
        <div className="field"><label htmlFor="automation-business">Business name *</label><input id="automation-business" name="business" required autoComplete="organization" /></div>
        <div className="field"><label htmlFor="automation-industry">Industry</label><input id="automation-industry" name="industry" placeholder="e.g. salon, clinic, retail" /></div>
        <div className="field"><label htmlFor="automation-email">Email *</label><input id="automation-email" name="email" type="email" required autoComplete="email" /></div>
        <div className="field"><label htmlFor="automation-whatsapp">WhatsApp number (optional)</label><input id="automation-whatsapp" name="whatsapp" type="tel" autoComplete="tel" /></div>
        <div className="field full"><label htmlFor="automation-goal">What would you like to automate? *</label><textarea id="automation-goal" name="automationGoal" required minLength={10} placeholder="Describe the task or workflow you have in mind." /></div>
        <div className="field"><label htmlFor="automation-process">How does the process work today? (optional)</label><textarea id="automation-process" name="currentProcess" placeholder="A short description is enough." /></div>
        <div className="field"><label htmlFor="automation-problem">Where is the friction? (optional)</label><textarea id="automation-problem" name="problem" placeholder="What feels repetitive, slow or difficult?" /></div>
        <div className="field full"><button className="form-button" type="submit">REQUEST AN AUTOMATION CONVERSATION ↗</button></div>
      </form>
      {error && <p role="alert" className="form-error">{error} Browser validation will identify the specific field to correct.</p>}
      {sent && <p role="status" className="success-note">The details were validated in this browser only. Nothing has been sent or stored; connect an enquiry service or backend before accepting live automation enquiries.</p>}
      <p className="form-note">Frontend form only — enquiries are not sent or stored until an integration is configured.</p>
    </>
  );
}
