import { useState } from "react";
import type { FormEvent } from "react";

const services = ["Website development", "UI/UX design", "Digital presence", "AI automation", "Business systems", "Other"];

export default function AnishaEnquiryForm() {
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const form = event.currentTarget;
    if (!form.reportValidity()) {
      setError("Please check the required fields and try again.");
      return;
    }
    setError("");
    setSent(true);
    form.reset();
  }

  return (
    <>
      <form className="form-grid anisha-enquiry-form" onSubmit={submit} onInvalidCapture={() => setError("Please check the required fields and try again.")} onChange={() => { setError(""); if (sent) setSent(false); }}>
        <div className="field"><label htmlFor="anisha-name">Full name *</label><input id="anisha-name" name="name" required autoComplete="name" /></div>
        <div className="field"><label htmlFor="anisha-email">Email *</label><input id="anisha-email" name="email" type="email" required autoComplete="email" /></div>
        <div className="field"><label htmlFor="anisha-company">Business / company</label><input id="anisha-company" name="company" autoComplete="organization" /></div>
        <div className="field"><label htmlFor="anisha-whatsapp">WhatsApp number (optional)</label><input id="anisha-whatsapp" name="whatsapp" type="tel" autoComplete="tel" /></div>
        <div className="field full"><label htmlFor="anisha-service">Service required *</label><select id="anisha-service" name="service" required defaultValue=""><option value="" disabled>Select a service</option>{services.map(service => <option key={service}>{service}</option>)}</select></div>
        <div className="field full"><label htmlFor="anisha-description">What would you like to build? *</label><textarea id="anisha-description" name="description" required minLength={10} placeholder="A few sentences about your business and the project are enough." /></div>
        <div className="field full"><button className="form-button" type="submit">REQUEST A PROJECT CONVERSATION ↗</button></div>
      </form>
      {error && <p role="alert" className="form-error">{error} Browser validation will identify any specific field to correct.</p>}
      {sent && <p role="status" className="success-note">The details were validated in this browser only. Nothing has been sent or stored; connect an enquiry service or backend before accepting live project enquiries.</p>}
      <p className="form-note">Frontend form only — enquiries are not sent or stored until an integration is configured.</p>
    </>
  );
}
