import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { contact, socialProfiles } from "@/data/site";

const navItems = [
  ["About", "/about"], ["Work", "/work"], ["Anisha", "/anisha"],
  ["Movement", "/movement-on-wheels"], ["AI + Automation", "/ai-automation"],
  ["Software", "/software"], ["Skills", "/skills"],
] as const;

export function SiteHeader() {
  const [path] = useLocation();
  return <header className="site-header"><Link href="/" className="wordmark" aria-label="Anisha Singh home"><span className="wordmark-mark">AS</span><span>ANISHA<br/>SINGH</span></Link><nav aria-label="Main navigation" className="desktop-nav">{navItems.map(([label, href]) => { const active = href === "/work" ? path === href || path.startsWith("/work/") : path === href; return <Link key={href} href={href} aria-current={active ? "page" : undefined} className={active ? "nav-link active" : "nav-link"}>{label}</Link>; })}</nav><Link href="/contact" className="header-cta">LET'S TALK <span>↗</span></Link><details className="mobile-nav"><summary aria-label="Open navigation"><span></span><span></span></summary><nav aria-label="Mobile navigation">{[["Home", "/"], ...navItems, ["Contact", "/contact"]].map(([label, href]) => <Link key={href} href={href} onClick={event => { const menu = event.currentTarget.closest("details"); if (menu) menu.open = false; }}>{label}</Link>)}</nav></details></header>;
}

export function SiteFooter() {
  return <footer className="site-footer"><div className="footer-top"><div><p className="eyebrow">ANISHA SINGH</p><h2>Ideas into<br/><em>things that work.</em></h2></div><Link className="round-link" href="/contact" aria-label="Contact Anisha">↗</Link></div><div className="footer-bottom"><span>Digital Builder · Entrepreneur · Creative</span><div className="footer-links"><Link href="/">Home</Link><Link href="/about">About</Link><Link href="/work">Work</Link><Link href="/anisha">Anisha Digital</Link><Link href="/movement-on-wheels">Movement on Wheels</Link><Link href="/ai-automation">AI & Automation</Link><Link href="/software">Software</Link><Link href="/skills">Skills</Link><Link href="/contact">Contact</Link></div><div className="footer-contact"><a href={`mailto:${contact.email}`} aria-label="Email Anisha">Email Anisha ↗</a><a href={contact.phoneHref}>{contact.phone}</a></div><div className="footer-socials">{socialProfiles.map(profile => profile.href ? <a key={profile.label} href={profile.href} target="_blank" rel="noreferrer">{profile.label}</a> : <span key={profile.label} className="social-placeholder">{profile.label} / ADD LINK</span>)}</div><span>© {new Date().getFullYear()} ANISHA SINGH</span><a href="#top" className="back-top">BACK TO TOP ↑</a></div></footer>;
}

export function PageFrame({ children, title, description, showHeader = true }: { children: React.ReactNode; title: string; description: string; showHeader?: boolean }) {
  useEffect(() => {
    document.title = `${title} | Anisha Singh`;
    const desc = document.querySelector('meta[name="description"]');
    desc?.setAttribute("content", description);
    const ogTitle = document.querySelector('meta[property="og:title"]');
    ogTitle?.setAttribute("content", `${title} | Anisha Singh`);
    const ogDescription = document.querySelector('meta[property="og:description"]');
    ogDescription?.setAttribute("content", description);
    const twitterTitle = document.querySelector('meta[name="twitter:title"]');
    twitterTitle?.setAttribute("content", `${title} | Anisha Singh`);
    const twitterDescription = document.querySelector('meta[name="twitter:description"]');
    twitterDescription?.setAttribute("content", description);
  }, [title, description]);
  return <div id="top" className="site-frame">{showHeader && <SiteHeader/>}<main className="page-main">{children}</main><SiteFooter/></div>;
}

export function SectionLabel({ index, children }: { index: string; children: React.ReactNode }) { return <p className="section-label"><span>{index}</span><span>{children}</span></p>; }

export function PageIntro({ kicker, title, description }: { kicker: string; title: string; description: string }) {
  return <section className="page-intro wrap"><p className="eyebrow">{kicker}</p><h1>{title}</h1><p className="page-lede">{description}</p></section>;
}

export function ProjectVisual({ label, index, className = "" }: { label: string; index: string; className?: string }) {
  return <div className={`project-visual ${className}`} aria-label={`Illustrative placeholder for ${label}`}><div className="visual-top"><span>ANISHA / SELECTED WORK</span><span>{index}</span></div><div className="visual-center"><span className="visual-index">{index}</span><span className="visual-title">{label}</span><span className="visual-sub">PROJECT PREVIEW · PLACEHOLDER</span></div><div className="visual-bottom"><span>EDITORIAL STUDY</span><span>↗</span></div></div>;
}

export function CTA({ title, text, href = "/contact", label = "START A CONVERSATION" }: { title: string; text: string; href?: string; label?: string }) {
  return <section className="cta-panel wrap"><div><p className="eyebrow">OPEN TO IDEAS</p><h2>{title}</h2><p>{text}</p></div><Link className="cta-link" href={href}>{label}<span>↗</span></Link></section>;
}
